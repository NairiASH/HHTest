﻿using HHTest;

namespace FigureTest
{
    [TestClass]
    public class TriangleTest
    {
        [TestMethod]
        public void GetSquareTest()
        {
            double a = 3;
            double b = 4;
            double c = 5;
            Triangle triangle = new Triangle(a,b,c);
            double p = (a + b + c) / 2;
            double expected = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

            double actual = triangle.Square();

            Assert.AreEqual(expected, actual,"Площадь треугольника посчитана неверно");
        }
    }
}
