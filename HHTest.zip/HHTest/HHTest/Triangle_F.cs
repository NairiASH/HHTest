﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHTest
{
    public partial class Triangle_F : Form
    {
        public Triangle_F()
        {
            InitializeComponent();
        }

        private void Triangle_F_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Если пользователь нажал на кнопку ОК, проверяем введенные данные
            if (DialogResult == DialogResult.OK)
            {
                try
                {
                    try
                    {
                        double a = Convert.ToDouble(A_TB.Text);
                        double b = Convert.ToDouble(B_TB.Text);
                        double c = Convert.ToDouble(C_TB.Text);
                        if (a <= 0 || b <= 0 || c <= 0)
                        {
                            A_TB.Focus();
                            throw new Exception("Сторона треугольника не может быть меньше или равна нулю");
                        }
                    }
                    catch (FormatException)
                    {
                        e.Cancel = true;                        
                        MessageBox.Show("Стороны треугольника являются вещественными", "Ошибка");
                    }
                }
                catch (Exception E)
                {
                    e.Cancel = true;
                    MessageBox.Show(E.Message, "Ошибка");
                }
            }
        }
    }
}
