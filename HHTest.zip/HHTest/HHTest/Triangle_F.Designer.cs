﻿namespace HHTest
{
    partial class Triangle_F
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel_TB = new System.Windows.Forms.Button();
            this.Ok_TB = new System.Windows.Forms.Button();
            this.A_TB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.B_TB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.C_TB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Cancel_TB
            // 
            this.Cancel_TB.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel_TB.Location = new System.Drawing.Point(109, 105);
            this.Cancel_TB.Name = "Cancel_TB";
            this.Cancel_TB.Size = new System.Drawing.Size(75, 23);
            this.Cancel_TB.TabIndex = 7;
            this.Cancel_TB.Text = "Отмена";
            this.Cancel_TB.UseVisualStyleBackColor = true;
            // 
            // Ok_TB
            // 
            this.Ok_TB.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Ok_TB.Location = new System.Drawing.Point(28, 105);
            this.Ok_TB.Name = "Ok_TB";
            this.Ok_TB.Size = new System.Drawing.Size(75, 23);
            this.Ok_TB.TabIndex = 6;
            this.Ok_TB.Text = "Ок";
            this.Ok_TB.UseVisualStyleBackColor = true;
            // 
            // A_TB
            // 
            this.A_TB.Location = new System.Drawing.Point(58, 26);
            this.A_TB.Name = "A_TB";
            this.A_TB.Size = new System.Drawing.Size(110, 20);
            this.A_TB.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "A";
            // 
            // B_TB
            // 
            this.B_TB.Location = new System.Drawing.Point(58, 52);
            this.B_TB.Name = "B_TB";
            this.B_TB.Size = new System.Drawing.Size(110, 20);
            this.B_TB.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "B";
            // 
            // C_TB
            // 
            this.C_TB.Location = new System.Drawing.Point(58, 78);
            this.C_TB.Name = "C_TB";
            this.C_TB.Size = new System.Drawing.Size(110, 20);
            this.C_TB.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "C";
            // 
            // Triangle_F
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(206, 141);
            this.Controls.Add(this.C_TB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.B_TB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Cancel_TB);
            this.Controls.Add(this.Ok_TB);
            this.Controls.Add(this.A_TB);
            this.Controls.Add(this.label1);
            this.Name = "Triangle_F";
            this.Text = "Добавление треугольника";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Triangle_F_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancel_TB;
        private System.Windows.Forms.Button Ok_TB;
        public System.Windows.Forms.TextBox A_TB;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox B_TB;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox C_TB;
        private System.Windows.Forms.Label label3;
    }
}