﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HHTest
{
    public partial class Circle_F : Form
    {
        public Circle_F()
        {
            InitializeComponent();
        }

        private void Circle_F_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Если пользователь нажал на кнопку ОК, проверяем введенные данные
            if (DialogResult == DialogResult.OK)
            {
                try
                {                    
                    try
                    {                        
                        double r = Convert.ToDouble(R_TB.Text);                        
                        if (r < 0)
                        {
                            R_TB.Focus();
                            throw new Exception("Радиус не может быть отрицательным");
                        }
                    }
                    catch (FormatException)
                    {
                        e.Cancel = true;
                        R_TB.Focus();
                        MessageBox.Show("Радиус является вещественным цислом", "Ошибка");                        
                    }                                        
                }                
                catch (Exception E)
                {
                    e.Cancel = true;
                    MessageBox.Show(E.Message, "Ошибка");
                }
            }
        }
    }
}
