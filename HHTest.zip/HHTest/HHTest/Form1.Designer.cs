﻿namespace HHTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Figures_LB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Add_TB = new System.Windows.Forms.Button();
            this.Delete_B = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Triangle_RB = new System.Windows.Forms.RadioButton();
            this.Circle_RB = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Square_TB = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Figures_LB
            // 
            this.Figures_LB.FormattingEnabled = true;
            this.Figures_LB.Location = new System.Drawing.Point(12, 42);
            this.Figures_LB.Name = "Figures_LB";
            this.Figures_LB.Size = new System.Drawing.Size(165, 173);
            this.Figures_LB.TabIndex = 0;
            this.Figures_LB.SelectedIndexChanged += new System.EventHandler(this.Figures_LB_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Список фигур";
            // 
            // Add_TB
            // 
            this.Add_TB.Location = new System.Drawing.Point(186, 118);
            this.Add_TB.Name = "Add_TB";
            this.Add_TB.Size = new System.Drawing.Size(75, 23);
            this.Add_TB.TabIndex = 2;
            this.Add_TB.Text = "Добавить";
            this.Add_TB.UseVisualStyleBackColor = true;
            this.Add_TB.Click += new System.EventHandler(this.Add_TB_Click);
            // 
            // Delete_B
            // 
            this.Delete_B.Enabled = false;
            this.Delete_B.Location = new System.Drawing.Point(186, 147);
            this.Delete_B.Name = "Delete_B";
            this.Delete_B.Size = new System.Drawing.Size(75, 23);
            this.Delete_B.TabIndex = 4;
            this.Delete_B.Text = "Удалить";
            this.Delete_B.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Triangle_RB);
            this.groupBox1.Controls.Add(this.Circle_RB);
            this.groupBox1.Location = new System.Drawing.Point(186, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(137, 70);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Выберите фигуру";
            // 
            // Triangle_RB
            // 
            this.Triangle_RB.AutoSize = true;
            this.Triangle_RB.Location = new System.Drawing.Point(6, 42);
            this.Triangle_RB.Name = "Triangle_RB";
            this.Triangle_RB.Size = new System.Drawing.Size(90, 17);
            this.Triangle_RB.TabIndex = 4;
            this.Triangle_RB.Text = "Треугольник";
            this.Triangle_RB.UseVisualStyleBackColor = true;
            // 
            // Circle_RB
            // 
            this.Circle_RB.AutoSize = true;
            this.Circle_RB.Checked = true;
            this.Circle_RB.Location = new System.Drawing.Point(6, 19);
            this.Circle_RB.Name = "Circle_RB";
            this.Circle_RB.Size = new System.Drawing.Size(48, 17);
            this.Circle_RB.TabIndex = 3;
            this.Circle_RB.TabStop = true;
            this.Circle_RB.Text = "Круг";
            this.Circle_RB.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(183, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Площадь";
            // 
            // Square_TB
            // 
            this.Square_TB.Location = new System.Drawing.Point(243, 199);
            this.Square_TB.Name = "Square_TB";
            this.Square_TB.ReadOnly = true;
            this.Square_TB.Size = new System.Drawing.Size(83, 20);
            this.Square_TB.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 229);
            this.Controls.Add(this.Square_TB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Delete_B);
            this.Controls.Add(this.Add_TB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Figures_LB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Figures_LB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Add_TB;
        private System.Windows.Forms.Button Delete_B;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Triangle_RB;
        private System.Windows.Forms.RadioButton Circle_RB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Square_TB;
    }
}

