﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHTest
{
    public class Triangle : IFigure
    {
        private double _A, _B, _C;

        //Треугольник по умолчанию
        public Triangle()
        {
            _A = 2;
            _B = 3;
            _C = 4;
        }

        //Равнобедренный треугольник
        public Triangle(double EachSide)
        {
            if (EachSide > 0)
                _A = _B = _C = EachSide;                   
        }

        public Triangle(double NewA, double NewB, double NewC)
        {
            if (NewA > 0 && NewB > 0 && NewC > 0)
            {
                _A = NewA;
                _B = NewB;
                _C = NewC;
                if (!IsValid())                
                    throw new ArgumentException("Треугольник неправильный");

            }
            else throw new ArgumentException("Стороны треугольника должны быть положительными");
        }

        public double A
        {
            get { return _A; }
        }

        public double B
        {
            get { return _A; }
        }

        public double C
        {
            get { return _A; }
        }

        public double Square()
        {
            //Если треугольник прямоугольный, находим его площадь по соответствующей формуле
            if (IsRectangular())
            {
                return _A * _B / 2;
            }
            //В противном случае используем формулу Герона
            else
            {
                double p = Perimetr() / 2;
                return Math.Sqrt(p * (p - _A) * (p - _B) * (p - _C));
            }
        }

        public double Perimetr()
        {
            return _A + _B + _C;
        }

        //Является ли треугольник правильным
        public bool IsValid()
        {
            if (_A + _B <= _C || _A + _C <= _B || _B + _C <= _A)
                return false;
            else
                return true;
        }

        //Является ли треугольник прямоугольным
        public bool IsRectangular()
        {
            return _A * _A + _B * _B == _C * _C;
        }

        public override string ToString()
        {
            return String.Format("Треугольник({0}, {1}, {2})",_A.ToString(), _B.ToString(), _C.ToString());
        }
    }
}
