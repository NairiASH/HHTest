﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace HHTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Add_TB_Click(object sender, EventArgs e)
        {
            if (Circle_RB.Checked)
            {
                Circle_F dialog = new Circle_F();
                dialog.Text = "Добавление круга";
                dialog.R_TB.Text = "";                
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    Circle figure = new Circle(Convert.ToDouble(dialog.R_TB.Text));                    
                    Figures_LB.Items.Add(figure);
                }
            }
            else
            {
                Triangle_F dialog = new Triangle_F();
                dialog.Text = "Добавление треугольника";
                dialog.A_TB.Text = "";
                dialog.B_TB.Text = "";
                dialog.C_TB.Text = "";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    Triangle figure = new Triangle(Convert.ToDouble(dialog.A_TB.Text), 
                                                   Convert.ToDouble(dialog.B_TB.Text),
                                                   Convert.ToDouble(dialog.C_TB.Text));
                    Figures_LB.Items.Add(figure);
                }
            }
        }

        //Данное событие срабатывает при выборе фигуры в листбоксе
        private void Figures_LB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Figures_LB.SelectedIndex >= 0)
            {
                Delete_B.Enabled = true;
                //Третье условие тестового задания.
                //И в данной строчке реализуется полиморфизм.
                //На основе интерфейса, который наследуют оба класса,
                //создается объект, который присваивается фигуре из листбокса.
                //В зависимости от потомка интерфейса площадь будет считать по разному
                IFigure Func = Figures_LB.SelectedItem as IFigure;
                Square_TB.Text = Func.Square().ToString();
            }
            else Delete_B.Enabled = false;
        }
    }
}