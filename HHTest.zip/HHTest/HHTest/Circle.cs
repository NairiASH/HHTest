﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHTest
{
    public class Circle : IFigure
    {
        private double _Radius;

        //Круг по умолчанию
        public Circle()
        {
            _Radius = 1;
        }

        public Circle(double NewRadius)
        {
            if (NewRadius >= 0)
                _Radius = NewRadius;
            else throw new ArgumentException("Радиус не может быть отрицательным");
        }

        public double Radius
        {
            get { return _Radius; }
        }

        public double Square()
        {
            return Math.PI * _Radius * _Radius;
        }

        public double Perimetr()
        {
            return 2 * Math.PI * _Radius;
        }

        public override string ToString()
        {
            return "Круг(" + _Radius.ToString() + ")";
        }
    }
}